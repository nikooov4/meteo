"""Wait for a workspace generation, then run the frozen scale protocol and acceptance checks."""

import argparse
import json
import time
from pathlib import Path

import psutil

from meteo_bridge.resources import atomic_json, sha256_file
from meteo_bridge.scale_benchmark import run_scale_benchmark
from meteo_bridge.scale_data import write_truth_labels


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--generator-pid", type=int, required=True)
    parser.add_argument("--output", type=Path, default=Path("reports/scale"))
    args = parser.parse_args()
    announced = 0
    monitor_errors = []
    while True:
        try:
            manifest = json.loads(args.manifest.read_text(encoding="utf8"))
        except (PermissionError, json.JSONDecodeError) as exc:
            monitor_errors.append({"unix_time": time.time(), "error": str(exc)})
            if not psutil.pid_exists(args.generator_pid):
                raise
            time.sleep(0.25)
            continue
        if manifest["status"] == "complete":
            break
        if not psutil.pid_exists(args.generator_pid):
            raise RuntimeError(f"generation ended with {manifest['status']}; scale acceptance not_run")
        if time.monotonic() - announced >= 60:
            print(json.dumps({"phase": "await_generation", "data_bytes": manifest["data_bytes"]}), flush=True)
            announced = time.monotonic()
        time.sleep(5)
    manifest["truth_labels"] = write_truth_labels(manifest, args.manifest.parent)
    atomic_json(args.manifest, manifest)
    atomic_json("data/manifests/synthetic-200gb.json", manifest)
    print("Generation complete; start integrated full verification/scan/Queries", flush=True)
    result = run_scale_benchmark(args.manifest, output=args.output, memory_limit="16GiB", query_count=12)
    report_path = args.output / "scale_report.json"
    report = json.loads(report_path.read_text())
    for key, filename in (
        ("disk_hardware", "reports/disk-hardware.json"),
        ("cpu_hardware", "reports/cpu-hardware.json"),
    ):
        if Path(filename).exists():
            report[key] = json.loads(Path(filename).read_text(encoding="utf-8-sig"))
    report["disk_type"] = "HDD: ST1000LM048-2E7172, D: NTFS"
    report["generation_run"] = manifest["generation_run"]
    report["generation_resume_count"] = manifest["resume_count"]
    report["monitor_transient_errors"] = monitor_errors
    report["generation_crash_exercise"] = "reports/scale/crash-exercise.json"
    largest = next((p for p in report["profiles"] if p["target_bytes"] == 200000000000), {})
    criteria = {
        "actual_data_bytes_at_least_200GB": manifest["data_bytes"] >= 200000000000,
        "full_byte_verification": report["verification"]["status"] == "full_verified",
        "complete_full_scan": largest.get("status") == "complete"
        and largest.get("scan_bytes") == manifest["data_bytes"],
        "query_batch_checked": len(largest.get("queries", [])) >= 24
        and all(q["bundle"]["checker"]["valid"] for q in largest.get("queries", [])),
        "LP_samples_checked": sum(q["lp_checked"] for q in largest.get("queries", [])) >= 4,
        "benchmark_RAM_within_16GiB": largest.get("peak_process_tree_rss", 2**64) <= 16 * 2**30,
        "generator_RAM_within_2GiB": manifest["generation_run"]["peak_process_tree_rss"] <= 2**31,
        "generation_resume_exercised": manifest.get("resume_count", 0) >= 2,
        "no_unexpected_benchmark_errors": not report["errors"],
    }
    report["acceptance"] = {
        "status": "passed" if all(criteria.values()) else "failed",
        "criteria": criteria,
        "scope": "synthetic scale only; sampled RSS; OS cache uncontrolled; no real-200GB claim",
    }
    atomic_json(report_path, report)
    atomic_json(
        args.output / "acceptance.json", {**report["acceptance"], "report_sha256": sha256_file(report_path)}
    )
    with (args.output / "scale_report.md").open("a", encoding="utf8") as f:
        f.write("\nSynthetic acceptance: **" + report["acceptance"]["status"] + "**.\n")
        f.write("\nDisk D: HDD ST1000LM048-2E7172, NTFS. All bytes/statuses are measured.\n")
        f.write("Generation resume was checked after an intentional worker crash. Real-200GB: not_run.\n")
    print(json.dumps({"benchmark": result, "acceptance": report["acceptance"]}, indent=2), flush=True)
    if not all(criteria.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
