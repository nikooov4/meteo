"""Local FastAPI adapter. All numerical answers come from services.solve_query."""

import json
import os
import tempfile
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException, UploadFile
from pydantic import Field

from .catalog import connect
from .domain import Case, Model, Query, digest
from .imports import import_file
from .services import apply_evidence, solve_query

app = FastAPI(title="MeteoBridge", version="0.1.0")
MAX_UPLOAD = 20 * 2**20


class QueryRequest(Model):
    dataset_id: str
    query: Query | None = None
    solver: str = Field(default="graph", pattern="^(graph|shared|cache|lp)$")


def _bundle(qid):
    with connect() as db:
        row = db.execute("SELECT payload FROM queries WHERE id=? ORDER BY revision DESC LIMIT 1", (qid,)).fetchone()
    if row is None:
        raise HTTPException(404, "query not found")
    return json.loads(row[0])


@app.get("/health")
def health():
    return {"status": "ok", "version": "0.1.0", "offline": True}


@app.post("/datasets")
def upload_dataset(file: UploadFile):
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".json", ".yaml", ".yml", ".csv", ".nc"}:
        raise HTTPException(415, "unsupported format; archives are not accepted")
    home = Path(os.environ.get("METEOBRIDGE_HOME", ".meteo"))
    home.mkdir(parents=True, exist_ok=True)
    filename = None
    try:
        with tempfile.NamedTemporaryFile(dir=home, suffix=suffix, delete=False) as f:
            filename = f.name
            total = 0
            while block := file.file.read(65536):
                total += len(block)
                if total > MAX_UPLOAD:
                    raise HTTPException(413, "20 MiB upload limit; large archives are registered through CLI")
                f.write(block)
        case = import_file(filename)
        dataset_id = digest(case)
        with connect() as db:
            db.execute("INSERT OR IGNORE INTO datasets VALUES (?,?)", (dataset_id, case.model_dump_json()))
        return {"id": dataset_id, "rows": len(case.observations), "query": case.query.model_dump()}
    except (ValueError, KeyError, OSError) as exc:
        raise HTTPException(422, str(exc)) from exc
    finally:
        if filename:
            Path(filename).unlink(missing_ok=True)


@app.get("/datasets/{dataset_id}/schema")
def schema(dataset_id: str):
    with connect() as db:
        row = db.execute("SELECT payload FROM datasets WHERE id=?", (dataset_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "dataset not found")
    case = Case.model_validate_json(row[0])
    return {"series": case.query.series.model_dump(), "observations_preview": [o.model_dump() for o in case.observations[:20]],
            "hypotheses": [h.model_dump() for h in case.hypotheses], "h_complete": case.h_complete,
            "provenance": [s.model_dump() for s in case.source_manifests]}


@app.post("/queries")
def create_query(request: QueryRequest):
    with connect() as db:
        row = db.execute("SELECT payload FROM datasets WHERE id=?", (request.dataset_id,)).fetchone()
    if row is None:
        raise HTTPException(404, "dataset not found")
    case = Case.model_validate_json(row[0])
    if request.query:
        case.query = request.query
    bundle = solve_query(case, request.solver)
    qid = uuid.uuid4().hex
    with connect() as db:
        db.execute("INSERT INTO queries VALUES (?,?,?)", (qid, case.revision, json.dumps(bundle)))
    return {"id": qid, **bundle}


@app.get("/queries/{qid}")
def get_query(qid: str):
    return _bundle(qid)["result"]


@app.get("/queries/{qid}/certificate")
def certificate(qid: str):
    return _bundle(qid).get("certificate")


@app.get("/queries/{qid}/witnesses")
def witnesses(qid: str):
    return _bundle(qid)["result"].get("witnesses", [])


@app.get("/queries/{qid}/actions")
def actions(qid: str):
    return _bundle(qid)["result"].get("suggested_actions", [])


@app.post("/queries/{qid}/evidence")
def evidence(qid: str, payload: dict):
    try:
        case = apply_evidence(Case.model_validate(_bundle(qid)["case"]), payload)
        bundle = solve_query(case)
        with connect() as db:
            db.execute("INSERT INTO queries VALUES (?,?,?)", (qid, case.revision, json.dumps(bundle)))
        return {"id": qid, **bundle}
    except (ValueError, KeyError) as exc:
        raise HTTPException(422, str(exc)) from exc


@app.get("/queries/{qid}/export")
def export(qid: str):
    return _bundle(qid)
