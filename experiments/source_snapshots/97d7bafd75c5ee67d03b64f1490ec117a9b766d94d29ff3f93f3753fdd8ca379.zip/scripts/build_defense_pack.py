"""Build Russian defense reports from saved runs; never invent or rerun measurements."""

import csv
import json
import os
import re
import shutil
import zipfile
from fractions import Fraction as F
from pathlib import Path
from statistics import mean, median

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from meteo_bridge.resources import atomic_json, sha256_file

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "defense"
RUNS = ROOT / "experiments/runs"


def read(path):
    return json.loads(Path(path).read_text(encoding="utf8"))


def width(bounds):
    return None if bounds["upper"] is None else F(bounds["upper"])-F(bounds["lower"])


def timed_rows(records, methods):
    return "\n".join(f"| {m} | {median(r['methods'][m]['seconds'] for r in records)*1000:.3f} |"
                     for m in methods) if records else "| нет завершённых задач | — |"


def write(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(text, encoding="utf8")


def real_report(run):
    records = run["records"]
    lines = []
    for arm in run["protocol"]["arms"]:
        rows = [r for r in records if r["arm"]==arm]
        exact = sum(width(r["refinement_bounds"][-1])==0 for r in rows)
        initially_exact = sum(width(r["refinement_bounds"][0])==0 for r in rows)
        shrunk = sum(width(r["refinement_bounds"][0]) is None or
                     width(r["refinement_bounds"][-1])<width(r["refinement_bounds"][0]) for r in rows)
        unbounded = sum(width(r["refinement_bounds"][0]) is None for r in rows)
        lines.append(f"| {arm} | {len(rows)} | {initially_exact} | {unbounded} | {shrunk} | {exact} |")
    return f"""# Метод на реальных ERA5 LSP: сохранённый эксперимент

Дата 2026-10-19. Статус: **{run['status']}**. Метод применён к реальным encoded
метеоданным реанализа, с явно контролируемой потерей временной детализации.
Научный приоритет и independent Gate B этим не устанавливаются.

## Дизайн

В 12 исходных NCAR ERA5 HRES LSP файлах 2023 года заранее выбраны циклы дня 11
06 UTC и шесть фиксированных grid points: Moscow, Singapore, North Atlantic,
New York, Tokyo, Sydney. Это 72 point/cycle windows, **864 исходных hourly values**.
Все сухие случаи сохранены. Выбор не зависел от увиденного количества осадков.
Эти дни исключались из training bank синтетики, но уже использовались в её
development holdout; это не новые независимые source families или экспертная разметка.

Общий размер source files **{sum(s['bytes'] for s in run['sources']):,} bytes**.
SHA256 всех 12 файлов заново проверены. Для анализа читается один native 12-hour
global field за раз, около 50 MB float32; в solver поступают ограниченные point cases.
Не весь глобальный архив передаётся в один граф.

Conventions: documented previous-hour LSP amount, native units m, точный rational
перевод encoded binary float в mm. Соседние amounts не вычитаются. LSP — только
крупномасштабная компонента реанализа, не total precipitation и не gauge observation.

Почасовые значения укрупняются в четыре-часовые суммы при accepted QC; отсутствующие
значения не восстанавливаются. Запрос — первые пять часов, eps=0.05 mm.
Сравниваются documented H1 и controlled shift H2. Во второй ветке сдвиг внесён
нами в один укрупнённый интервал; он способен оставить непокрытый час и unbounded
ответ. Это проверка явно объявленного perturbation model, а не естественный дефект ERA5.
Гипотетическая eta — bounded error добавляемого наблюдения, не sensor calibration.

## Результаты

Всего **{len(records)} задач**, **{len(records)*len(run['protocol']['methods'])} profile bundles**.
Все четыре метода прошли checker и сравнение с независимым paired-increment LP
на eta=0,0.1,1 mm. Это **{len(records)*4*3} различных action/radius comparisons**,
каждое сверено для четырёх методов; LP calls для профилей — {sum(r['lp_calls'] for r in records)}.
Численная tolerance 1e-7. LP grid не доказывает всю кривую; отдельный checker
проверяет all-finite-eta certificate.

| Ветка | Cases | Уже exact до уточнений | Unbounded до уточнений | Bounds сузились | Exact после всех hourly observations |
|---|---:|---:|---:|---:|---:|
{chr(10).join(lines)}

Во всех случаях проверены вложенные наборы 0/3/6/12 исходных observations:
lower не уменьшается, upper не увеличивается; Query bounds независимо сверены с LP.
Дополнительные сведения для этого же места/цикла сужают ответ; объём постороннего
архива не использован как замена информации. Сухие исходно exact случаи не исключены.

Медианные cold end-to-end ms, включая построение/проверку всего профиля:

| Метод | Median ms |
|---|---:|
{timed_rows(records,run['protocol']['methods'])}

Это один shuffled проход на задачу, не significance study. При documented H1
полный Python graph может быть быстрее terminal: результаты не подгонялись под
обязательный выигрыш. Numerical LP и repeated-input cache не считаются равным
по контракту cold all-profile timing comparator. Одновременно выполнялся отдельный
background archive job; его IO/RAM не следует приписывать этому процессу.

Wall time: **{run['wall_seconds']:.3f} s**, sampled process-tree peak RSS
**{run['peak_process_tree_rss']:,} bytes**, budget 2 GiB. Ошибок записано: {len(run['errors'])}.
Источник runs: `experiments/runs/precision-real-era5-v1/`, protocol в
`configs/experiments/precision-real-era5-v1.json`; там же input/certificates/LP,
source snapshot, версии, hashes и replay.json. ZIP bundles содержат обычный JSON.

```powershell
uv run python scripts/run_real_precision_experiment.py --output experiments/runs/precision-real-era5-reproduction
```

Применимость означает корректную работу реализованного математического контракта
на указанных реальных значениях. Она не означает доказанную полноту всех реальных
metadata alternatives, природное происхождение controlled дефектов, независимый
Gate B, лучший прогноз или установленную новизну.
"""


def archive_report(run):
    rows = run["records"]
    p = run["protocol"]
    invocation = run["invocations"][-1]
    final = run["status"]=="complete"
    return f"""# Precision method и 200-GB архив

Дата 2026-10-19. Фактический статус: **{run['status']}**.
Обработано **{len(rows)}/{run['plan']['shards']} partitions**,
проверено SHA256 **{sum(r['bytes'] for r in rows):,} bytes** из
**{run['plan']['data_bytes']:,} bytes**. Числа ниже относятся только к завершённым задачам.

## Что именно проверяется

Это существующий synthetic legacy-v1, не новая реалистичная синтетика v2.
Одна seeded серия и 12/24-hour window из каждого manifest shard выбираются
без анализа rainfall values. Сохраняются zero/missing/rejected случаи.
Amount и mean rate агрегируются только по accepted источникам, cumulative
сохраняется на документированных four-hour endpoints в пределах одного reset cycle.
В constructed задаче задаются 2/3 явные controlled metadata alternatives;
полнота H относится к этим объявленным сдвигам, не ко всем смыслам реального файла.

Полный точный graph, compiled full graph, terminal без reuse и terminal reuse
получают одинаковые данные, действия, стоимость и proof contract.
Сравнивается вычисление oracle, не policy. Нет доступа к скрытым ответам simulator.
Whole-profile four-entry cache проверяется отдельно на повторном одинаковом входе;
warm hit не сравнивается с cold candidate как одинаковый режим.

Профиль независимо сравнивается с paired LP для eta=0,0.1,1 mm и проверяется checker.
Native Query и четыре вложенных уровня возвращённых observations также сверяются
с LP и сохраняют сертификаты. Проверяется сужение bounds при добавлении полезных
наблюдений. Нет произвольного hourly disaggregation или соединения физических серий.

## Текущее измеренное состояние

Profile bundles: **{len(rows)*len(p['methods'])}**; уникальные action/radius comparisons
на каждый метод: **{len(rows)*4*len(p['radii'])}**. Ошибки run: **{len(run['errors'])}**.

| Метод | Median ms по завершённым задачам |
|---|---:|
{timed_rows(rows,p['methods']+['cache_warm'])}

Последняя invocation: hashed bytes {invocation['hashed_bytes']:,},
hash time {invocation['hash_seconds']:.3f} s;
финализированный peak RSS: {invocation.get('peak_process_tree_rss','ещё не записан')} bytes.
Invocations: {len(run['invocations'])}; resume invocations:
{sum(i['resume'] for i in run['invocations'])}.
Ранние прерывания/checkpoints сохраняются; invocation без финальных wall/RSS
не превращается в завершённое измерение. На resume повторно сверяются hashes
прошлых shards и готовых bundles. Повторно прочитанные bytes не увеличивают
уникальный размер набора.

{'Полный partition-wide run завершён. Это не перебор всех возможных Query архива.' if final else 'Полный новый эксперимент ещё не завершён. Результат 200 GB не заявляется по этому частичному run.'}

Исторический full-normalization streaming scan 1/10/50/200 GB уже сохранён
отдельно в `reports/scale/scale_report.json`. В новом исследовании выполняется
SHA256 streaming read каждого data file плюс bounded extraction и profile study;
это не новый full normalization scan всех rainfall records. Старые результаты
не переименовываются в новые и не доказывают реалистичность legacy-v1.

```powershell
uv run python scripts/run_archive_precision_benchmark.py --dry-run
uv run python scripts/run_archive_precision_benchmark.py --resume
uv run python scripts/run_archive_precision_benchmark.py --replay
```

Для независимого повторного запуска выбирайте новый `--output`.
Обычные tests/CI используют только маленький smoke, не автоматические 200 GB.
Protocol: `configs/experiments/precision-archive-200gb-v1.json`; входы, все четыре
профиля, LP grids и refinements сохранены в отдельных ZIP bundles в
`experiments/runs/precision-archive-200gb-v1/`. Budget process+workers 16 GiB,
один worker, report disk budget 1 GiB. Архив целиком в RAM не помещается.
Gate B остаётся pending, приоритет unestablished.
"""


def examples(real, archive):
    dest = OUT / "examples"
    dest.mkdir(exist_ok=True)
    inputs = list((RUNS / "precision-frontier-v1").glob("*-input.json"))
    for src in inputs:
        (dest / "method_inputs").mkdir(exist_ok=True)
        shutil.copy2(src,dest / "method_inputs" / src.name)
    selected = next(r for r in real["records"] if r["arm"]=="documented_H1" and
                    width(r["refinement_bounds"][0]) is not None and width(r["refinement_bounds"][0])>0)
    with zipfile.ZipFile(RUNS / "precision-real-era5-v1" / selected["bundle"]) as z:
        original = json.loads(z.read("native.json"))["case"]
        data = json.loads(z.read("input.json"))
        for name,value in [("real_native_case.json",original),("real_controlled_case.json",data["case"]),
                           ("real_actions.json",data["actions"]),("real_profile_bundle.json",json.loads(z.read("terminal.json")))]:
            atomic_json(dest / name,value)
    with (dest / "real_era5_hourly.csv").open("w",encoding="utf8",newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["start_epoch_UTC","end_epoch_UTC","original_m","amount_mm_exact","amount_mm_approx","QC"])
        for o in original["observations"]:
            writer.writerow([o["interval"]["start"],o["interval"]["end"],o["original_value"],o["lower"],
                             float(F(o["lower"])),o["qc"]])
    atomic_json(dest / "real_example_provenance.json",{
        "selection":"first fixed-order documented-H1 case with finite nonzero initial width; illustration only, benchmark retained every case",
        "record":selected,"run_sha256":sha256_file(RUNS / "precision-real-era5-v1/run.json")})
    if archive["records"]:
        r = archive["records"][0]
        with zipfile.ZipFile(RUNS / "precision-archive-200gb-v1" / r["bundle"]) as z:
            atomic_json(dest / "synthetic_200gb_case_input.json",json.loads(z.read("input.json")))
    write(dest / "README.md","""# Примеры данных

`method_inputs/` — девять исходных малых задач исторического precision pilot,
точные копии, всего 75 356 bytes. Это synthetic mathematical fixtures.

`real_era5_hourly.csv` и `real_native_case.json` — настоящие encoded значения
ERA5 LSP из нового real study. `real_controlled_case.json` содержит явно заданное
укрупнение; `real_actions.json` — hypothetical bounded-error interval acquisitions.
`real_profile_bundle.json` — профиль и сертификат кандидата.
Первый недегеративный documented-H1 пример выбран для иллюстрации после измерений;
это не правило отбора экспериментальных случаев. Все dry cases сохранены в run.

`synthetic_200gb_case_input.json` — ограниченная задача из первого shard legacy-v1,
а не весь 200-GB архив. Origin=controlled явно указывает экспериментальные изменения.

```powershell
uv run meteo acquisition precision --case defense/examples/real_controlled_case.json --actions defense/examples/real_actions.json --output outputs/defense-real
uv run meteo acquisition precision-verify outputs/defense-real
```
""")


def copy_sources():
    names = ["docs/project_explained_ru.md","docs/precision_frontier.md","docs/algorithm_delta.md",
             "docs/assumptions.md","docs/annotation_guide.md","docs/novelty_validation_plan.md",
             "docs/literature_delta_2026_10_17.md","reports/novelty_justification.md",
             "reports/novelty_prior_art_check.json","paper/novelty_statement_ru.md",
             "reports/delivery.md","reports/precision_frontier.md","reports/gate_a.md","reports/gate_b.md",
             "reports/review_status.json","reports/synthetic_realism.md","reports/weather_v2.md",
             "reports/weather_10gb.md","reports/scale/scale_report.md","reports/real_precision.md",
             "reports/archive_precision_200gb.md","reports/validation/archive-map-preview.png"]
    mapped = {(ROOT / name).resolve():OUT / "sources" / name for name in names}
    records = []
    for original,dest in mapped.items():
        dest.parent.mkdir(parents=True,exist_ok=True)
        changed = False
        if original.suffix==".md":
            def link(match):
                nonlocal changed
                target = match[2]
                if target.startswith(("http:","https:","#","app:","mailto:")):
                    return match[0]
                base,sep,fragment = target.partition("#")
                path = (original.parent / base).resolve()
                if not path.is_relative_to(ROOT):
                    return match[0]
                destination = mapped.get(path,path)
                relative = Path(os.path.relpath(destination,dest.parent)).as_posix()
                changed |= relative != base
                return f"[{match[1]}]({relative}{sep}{fragment})"
            text = re.sub(r"\[([^\]]+)\]\(([^)\n]+)\)",link,original.read_text(encoding="utf8"))
            write(dest,text)
        else:
            shutil.copy2(original,dest)
        records.append({"source":str(original.relative_to(ROOT)),"copy":str(dest.relative_to(OUT)),
                        "source_sha256":sha256_file(original),"copy_sha256":sha256_file(dest),"local_links_adjusted":changed})
    atomic_json(OUT / "sources/manifest.json",records)
    write(OUT / "sources/README.md","# Копии прежних и текущих материалов\n\n"
          "Текст, даты и результаты сохранены; локальные ссылки приведены к этой папке/репозиторию. "
          "Числа tests и статусы в старых документах относятся к их исходным версиям.\n\n"+
          "\n".join(f"- [{r['source']}]({Path(r['copy']).relative_to('sources').as_posix()})" for r in records))


def figures(real,archive):
    fig = make_subplots(rows=2,cols=2,subplot_titles=("Mean finite Query width, mm", "Unbounded Query cases",
                                                  "Real data: median profile ms", "200GB: completed-case median ms"))
    for arm in real["protocol"]["arms"]:
        rows = [r for r in real["records"] if r["arm"]==arm]
        finite, unbounded = [], []
        for i in range(4):
            ws = [width(r["refinement_bounds"][i]) for r in rows]
            finite.append(mean(float(w) for w in ws if w is not None) if any(w is not None for w in ws) else None)
            unbounded.append(sum(w is None for w in ws))
        fig.add_trace(go.Scatter(x=[0,3,6,12],y=finite,name=arm,mode="lines+markers",connectgaps=False),row=1,col=1)
        fig.add_trace(go.Scatter(x=[0,3,6,12],y=unbounded,name=arm+" unbounded",mode="lines+markers"),row=1,col=2)
        methods = real["protocol"]["methods"]
        fig.add_trace(go.Bar(x=methods,y=[median(r["methods"][m]["seconds"] for r in rows)*1000 for m in methods],
                             name=arm+" time"),row=2,col=1)
    if archive["records"]:
        methods=archive["protocol"]["methods"]+["cache_warm"]
        fig.add_trace(go.Bar(x=methods,y=[median(r["methods"][m]["seconds"] for r in archive["records"])*1000 for m in methods],
                             name="archive "+archive["status"]),row=2,col=2)
    fig.update_xaxes(title_text="Native hourly observations added",row=1,col=1)
    fig.update_xaxes(title_text="Native hourly observations added",row=1,col=2)
    fig.update_layout(height=900,title=f"MeteoBridge · saved studies · archive {archive['status']} · no priority claim",
                      barmode="group",margin=dict(t=100,b=110))
    write(OUT / "experiment_figures.html",fig.to_html(full_html=True,include_plotlyjs=True))


def main():
    real=read(RUNS / "precision-real-era5-v1/run.json")
    archive=read(RUNS / "precision-archive-200gb-v1/run.json")
    if real["status"]!="complete":
        raise ValueError("real experiment not complete; do not publish final real results")
    rr,ar = real_report(real),archive_report(archive)
    write(ROOT / "reports/real_precision.md",rr)
    write(ROOT / "reports/archive_precision_200gb.md",ar)
    write(OUT / "05_experiments_ru.md","# Эксперименты: применимость и пределы выводов\n\n"
          "Этот файл построен из сохранённых runs; новый archive status: **"+archive["status"]+"**.\n\n"+
          rr.replace("# Метод на реальных","## Метод на реальных",1)+"\n\n"+
          ar.replace("# Precision method","## Precision method",1))
    examples(real,archive)
    copy_sources()
    figures(real,archive)
    atomic_json(OUT / "artifact_manifest.json",{
        "date":"2026-10-19","archive_status":archive["status"],
        "archive_run_sha256":sha256_file(RUNS / "precision-archive-200gb-v1/run.json"),
        "real_run_sha256":sha256_file(RUNS / "precision-real-era5-v1/run.json"),
        "files":[{"path":str(p.relative_to(OUT)),"bytes":p.stat().st_size,"sha256":sha256_file(p)}
                 for p in sorted(OUT.rglob("*")) if p.is_file() and p.name!="artifact_manifest.json"]})
    print(json.dumps({"defense":str(OUT),"archive_status":archive["status"],"real_cases":len(real["records"])}))


if __name__=="__main__":
    main()
